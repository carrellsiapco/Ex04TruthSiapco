package ex04truthsiapco;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class Song {
    private String title;
    private String artist;
    private int minutes;
    private int seconds;
    
    public String getTitle(){
        return title;
    }
    public String getArtist(){
        return artist;
    }
    public int getMinutes(){
        return minutes;
    }
     public int getSeconds(){
        return seconds;
    }
    
    public Song(String t, String a, int m, int s){
    title = t;
    artist = a;
    minutes = m;
    seconds = s;
    }
    
    public void sing(){
        System.out.println(title + " is being performed by " + artist + ". It lasted " + minutes + " minutes and " + seconds + " seconds.");
    }
    
}

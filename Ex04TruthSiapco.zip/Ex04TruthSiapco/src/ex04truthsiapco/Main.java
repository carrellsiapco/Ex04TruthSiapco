/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex04truthsiapco;
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author admin
 */
public class Main {
      public static void main(String[] args){
    Scholars carrell = new Scholars("Carrell", "Chicken Breast", "Quezon City", 15);

    Scholars mia = new Scholars("Mia", "Popcorn", "Quezon City", 16);
      
    Scholars franco= new Scholars("Franco", "Pasta", "Quezon City", 15);

        carrell.introduce();
        
    Song inferno = new Song("Inferno", "Mrs. GREEN APPLE", 3, 33);
    Song sparkagain = new Song("SPARK-AGAIN", "Aimer", 4, 4);
    Song mandala = new Song("MANDALA", "chyxz", 4, 0);
    
    Singer reign = new Singer("Reign", 1,"Inferno" );
         reign.performForAudience(12);   
         reign.changeFaveSong("Mandala");

         
    Singer rice = new Singer("Rice", 1, "SPARK-AGAIN");
         reign.performForAudience(10, "Reign", "Rice");
     }   
}


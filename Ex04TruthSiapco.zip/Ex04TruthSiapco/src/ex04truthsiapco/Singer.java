/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex04truthsiapco;

public class Singer {
  private String name;
  private int noOfPerformances = 0;
  private double earnings = 0;
  private String faveSong;
  private static int totalPerformances = 0;
  
  public String getName(){
      return name;
  }
  public int getNo(){
      return noOfPerformances;
  }
  public double getEarnings(){
      return earnings;
  }
  public String getFave(){
      return faveSong;
  }
  
  public int getTotal(){
      return totalPerformances;
  }
  public Singer(String n, int o, String f){
    name = n;
    noOfPerformances = o;
    faveSong = f;
  }
  
  public void performForAudience(int people){
        earnings = ((people * 100) + earnings);
        noOfPerformances = noOfPerformances + 1;
        System.out.println(name + " sang " + faveSong + " for " + people + " people. Afterward, they earned P" + earnings);
  }
  public void performForAudience(int people, String Singer1, String Singer2){
        earnings = (people * 100);
        noOfPerformances = noOfPerformances ++;
        System.out.println(Singer1 + " and " + Singer2 + " sang " + faveSong + " for " + people + " people. Afterward, they each earned P" + earnings/2);
  }
  
  public void changeFaveSong(String newSong){
    faveSong = newSong;
  }
}

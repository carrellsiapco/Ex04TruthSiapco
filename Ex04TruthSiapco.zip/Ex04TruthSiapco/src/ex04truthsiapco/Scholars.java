/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex04truthsiapco;

public class Scholars {
    private String name;
    private String food;
    private String lastYearSection;
    private String address;
    private double gwa;
    private int age;
    
    public Scholars(String n, String f, String a, int e){
        name = n;
        food = f;
        address = a;
        age = e;
    }
    
    public String getName(){
        return name;
    }
    public String getFood(){
        return food;
    }
    public String getAddress(){
        return address;
    }
    public int getAge(){
        return age;
    }
     
    public void eat(){
        System.out.println( name + " ate their " + food + ". It tasted very nice." );
    }
    public void introduce(){
        System.out.println("Hi, I am " + name + ". I live in " + address + ". I am " + age + " years old. I look forward to working with you this school year.");
    }
  
}
